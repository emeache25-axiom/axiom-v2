"""
AXIOM v2 — Servicio de Alertas de Precio.

Evalúa las alertas activas contra el precio actual y notifica por Telegram
cuando el precio CRUZA el objetivo (no cuando simplemente está del otro lado).

La detección de cruce usa `last_side`: el lado del target donde estaba el
precio en la evaluación anterior. Solo se dispara cuando el lado cambia en la
dirección configurada.
"""
from __future__ import annotations
import os
import logging
import asyncio
import httpx

from backend.services.price_service import get_price

logger = logging.getLogger(__name__)

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID   = os.getenv("TELEGRAM_CHAT_ID", "")
_TIMEOUT = 8.0


async def send_telegram(text: str) -> bool:
    """Envía un mensaje por Telegram. Devuelve True si se envió OK."""
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        logger.warning("[alerts] Telegram no configurado (falta TOKEN o CHAT_ID)")
        return False
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    try:
        async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
            r = await client.post(url, json={
                "chat_id": TELEGRAM_CHAT_ID,
                "text": text,
                "parse_mode": "HTML",
                "disable_web_page_preview": True,
            })
            if r.status_code != 200:
                logger.error(f"[alerts] Telegram HTTP {r.status_code}: {r.text[:200]}")
                return False
            return True
    except Exception as exc:
        logger.error(f"[alerts] Error enviando Telegram: {exc}")
        return False


def _fmt_price(v: float) -> str:
    if v is None:
        return "—"
    return f"{v:,.2f}" if abs(v) >= 1 else f"{v:.8f}".rstrip("0").rstrip(".")


async def evaluate_alerts(pool) -> dict:
    """
    Evalúa todas las alertas activas. Para cada una:
      1. Obtiene el precio actual (exchange configurado, fallback PostgreSQL).
      2. Determina de qué lado del target está ahora ('above'/'below').
      3. Si cruzó en la dirección configurada respecto a last_side → dispara.
      4. Actualiza last_side siempre; al disparar, según `recurring`:
         - recurring=false → active=false (se desactiva)
         - recurring=true  → queda activa (volverá a disparar en el próximo cruce)

    Returns: { evaluated, triggered }
    """
    async with pool.acquire() as conn:
        alerts = await conn.fetch("""
            SELECT id, coin_id, symbol, exchange, direction, target_price,
                   recurring, note, last_side
            FROM price_alerts
            WHERE active = true
        """)

    if not alerts:
        return {"evaluated": 0, "triggered": 0}

    # Traer precios DB como fallback (una sola query)
    coin_ids = list({a["coin_id"] for a in alerts})
    async with pool.acquire() as conn:
        db_rows = await conn.fetch(
            "SELECT id, price FROM coins WHERE id = ANY($1)", coin_ids
        )
    db_map = {r["id"]: {"price": r["price"]} for r in db_rows}

    triggered = 0

    async def eval_one(a):
        nonlocal triggered
        db_price = db_map.get(a["coin_id"])
        pdata = await get_price(a["symbol"], a["exchange"], db_price)
        price = pdata.get("price")
        if price is None:
            return

        target = float(a["target_price"])
        side = "above" if price >= target else "below"
        prev = a["last_side"]
        direction = a["direction"]

        # Detección de cruce: disparar solo si el lado cambió hacia la dirección
        # objetivo. Si prev es NULL (primera evaluación), NO disparamos: solo
        # registramos el lado actual para evitar un disparo espurio inicial.
        crossed = (
            prev is not None
            and prev != side
            and side == direction
        )

        async with pool.acquire() as conn:
            if crossed:
                arrow = "🔺" if direction == "above" else "🔻"
                cond = "por encima de" if direction == "above" else "por debajo de"
                note = f"\n📝 {a['note']}" if a["note"] else ""
                msg = (
                    f"{arrow} <b>Alerta {a['symbol'].upper()}</b>\n"
                    f"Precio {cond} <b>${_fmt_price(target)}</b>\n"
                    f"Precio actual: <b>${_fmt_price(price)}</b>{note}"
                )
                await send_telegram(msg)
                triggered += 1

                if a["recurring"]:
                    await conn.execute("""
                        UPDATE price_alerts
                        SET last_side = $1, last_triggered_at = now(),
                            trigger_count = trigger_count + 1
                        WHERE id = $2
                    """, side, a["id"])
                else:
                    await conn.execute("""
                        UPDATE price_alerts
                        SET active = false, last_side = $1, last_triggered_at = now(),
                            trigger_count = trigger_count + 1
                        WHERE id = $2
                    """, side, a["id"])
            else:
                # Solo actualizar el lado conocido
                await conn.execute(
                    "UPDATE price_alerts SET last_side = $1 WHERE id = $2",
                    side, a["id"]
                )

    await asyncio.gather(*[eval_one(a) for a in alerts])
    return {"evaluated": len(alerts), "triggered": triggered}
